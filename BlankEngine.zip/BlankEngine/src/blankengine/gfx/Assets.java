package blankengine.gfx;

import java.awt.image.BufferedImage;

public class Assets {
    
    public static void init(){
    }
    
}
