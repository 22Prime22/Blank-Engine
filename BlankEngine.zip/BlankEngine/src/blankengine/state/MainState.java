package blankengine.state;

import java.awt.Graphics;
import blankengine.Handler;

public class MainState extends State {

    public MainState(final Handler handler) {
        super(handler);
    }

    @Override
    public void tick() {
    }

    @Override
    public void render(Graphics g) {
    }

    @Override
    public void init() {
    }
    
}
